#
# TABLE STRUCTURE FOR: arsip
#

DROP TABLE IF EXISTS `arsip`;

CREATE TABLE `arsip` (
  `id_arsip` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` enum('Surat Keputusan','Peraturan','Berkas Kerja','dokumen') NOT NULL,
  `tahun` char(4) NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `nama_dokumen` varchar(255) NOT NULL,
  `tentang` text NOT NULL,
  `tgl_dokumen` date NOT NULL,
  `tgl_upload` date NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_arsip`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (2, 'Surat Keputusan', '1999', 'Kepmendagri_47_th_99.pdf', 'Kepmendagri no 47 Tahun 1999', 'Pedoman Penilaian Kinerja Perusahaan Daerah Air Minum', '2023-05-11', '2023-05-11', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (4, 'Peraturan', '1993', 'Perda_No_2_Tahun_93_tentang_Pendirian_Pdam.pdf', 'Perda No 2 Tahun 1993', 'Pendirian Perusahaan  Daerah Air Minum Kabupaten Bondowoso Tingkat II Bondowoso', '1993-04-21', '2023-05-15', '');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (5, 'Surat Keputusan', '1996', 'SK_Direktur_NO_22_2_Tahun_96_Tentang_Struktur.pdf', 'SK Direktur No 22.2 Tahun 1996 ', 'Struktur  Organisasi, Uraian Tugas  dan Tata Kerja Perusahaan Daerah Air Minum Kabupaten Daerah Tingkat II Bondowoso', '1996-04-01', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (6, 'Surat Keputusan', '2017', 'SK_Bupati_No_188_45_Tahun_2017_Tentang_Tarif_Air.pdf', 'SK Bupati No 188.45/830/430.4.2/2017', 'Tarif Air Minum Pada Perusahaan Daerah Air Minum Kabupaten Bondowoso Tahun 2017', '2017-11-29', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (7, 'Surat Keputusan', '2022', 'SK_Bupati_No_188_45_Tahun_2022_Tentang_Tarif_Air.pdf', 'SK Bupati No 188.45/262/430.4.2/2022', 'Tarif Air Minum Pada Perusahaan Daerah Air Minum Kabupaten Bondowoso Tahun 2022', '2022-02-24', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (8, 'Surat Keputusan', '2021', 'SK_Direktur_No_188_tahun_2021_tentang_Hak_Minim.pdf', 'SK Direktur No 188/33.3/430.12/2021 ', 'Perubahan Penetapan Pemberlakuan Hak Minim (10)M3', '2021-11-01', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (9, 'Peraturan', '2015', 'Perda_no_3_tahun_2015_ttg_Penyertaan_Modal.pdf', 'Perda No 3 Tahun 2015', 'Penyertaan Modal Pemerintah Daerah Kepada Perusahaan Daerah Air Minum Kabupaten Bondowoso', '2015-11-30', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (10, 'Surat Keputusan', '2021', 'SK_Direktur_No_188_Tahun_2021_Tentang_Pedoman_Pengadaan_barang_jasa.pdf', 'SK Direktur No 188/01.4.2/430.12/2021 ', 'Pedoman Pelaksanaan Pengadaan Barang/Jasa  pada Perusahaan Daerah Air Minum Kabupaten Bondowoso', '2021-01-11', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (11, 'Peraturan', '2019', 'PERBUP_Perubahan_kedua_atas_Peraturan_Bupati_No_57_TAHUN_2013.pdf', 'PerBup No 8 Tahun 2019', 'Perubahan Kedua atas Peraturan Bupati Bondowoso No 57 tahun Tahun 2013 Tentang Petunjuk Pelaksanaan Peraturan Daerah Kabupaten Daerah Tingkat II Bondowoso No 2 Tahun 1993 Tentang Pendirian Perusahaan Daerah Air Minum Kabupaten Daerah Tingkat II Bondowoso', '2019-01-18', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (12, 'Peraturan', '2011', 'Perda_No_6_Tahun_2011_ttg_perubahan_pendirian_pdam.pdf', 'Perda No 6 Tahun 2011', 'Perubahan Atas  Peraturan Daerah Kabupaten Daerah Tingkat II Bondowoso No 2  Tahun 1993  Tentang Pendirian Perusahaan Daerah Air Minum  Kabupaten  Daerah Tingkat II Bondowoso', '2011-08-01', '2023-05-15', '-');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (17, 'Peraturan', '2018', 'Permendagri_Nomor_37_Tahun_2018.pdf', 'Permendagri No 37 Tahun 2018', 'Pengangkatan dan Pemberhentian Anggota Dewan Pengawas atau  Anggota Komisaris dan Anggota Direksi Badan Usaha Milik Daerah', '2018-05-07', '2023-05-16', '');
INSERT INTO `arsip` (`id_arsip`, `jenis`, `tahun`, `nama_file`, `nama_dokumen`, `tentang`, `tgl_dokumen`, `tgl_upload`, `keterangan`) VALUES (20, 'Peraturan', '2017', 'PERMENDAGRI_Nomor_11_Tahun_2017.pdf', 'Permendagri No 11 Tahun 2017', 'Pedoman Evaluasi Rancangan Peraturan Daerah Tentang\r\nPertanggungjawaban Pelaksanaan Anggaran Pendapatan Dan\r\nBelanja Daerah Dan Rancangan Peraturan Kepala Daerah\r\nTentang Penjabaran Pertanggungjawaban Pelaksanaan\r\nAnggaran Pendapatan Dan Belanja Daerah', '2017-02-22', '2023-05-16', '');


#
# TABLE STRUCTURE FOR: bagian
#

DROP TABLE IF EXISTS `bagian`;

CREATE TABLE `bagian` (
  `id_bagian` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bagian` varchar(50) NOT NULL,
  PRIMARY KEY (`id_bagian`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (1, 'Langganan');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (2, 'Umum');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (3, 'Keuangan');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (4, 'Pemeliharaan');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (5, 'Perencanaan');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (6, 'S P I');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (7, 'U P K');
INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES (8, 'A M D K');


#
# TABLE STRUCTURE FOR: data_rekening
#

DROP TABLE IF EXISTS `data_rekening`;

CREATE TABLE `data_rekening` (
  `id_rek` int(11) NOT NULL AUTO_INCREMENT,
  `id_upk` int(11) NOT NULL,
  `bln` int(2) NOT NULL,
  `thn` int(4) NOT NULL,
  `jml_rek` int(5) NOT NULL,
  `air_pakai` int(6) NOT NULL,
  `rupiah` int(10) NOT NULL,
  PRIMARY KEY (`id_rek`),
  KEY `id_upk` (`id_upk`),
  CONSTRAINT `data_rekening_ibfk_1` FOREIGN KEY (`id_upk`) REFERENCES `nama_upk` (`id_upk`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4;

INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (1, 1, 1, 2022, 5491, 84451, 466540360);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (2, 2, 1, 2022, 1296, 15230, 82427940);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (3, 3, 1, 2022, 1234, 16279, 88463300);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (4, 4, 1, 2022, 1628, 23955, 124977360);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (5, 5, 1, 2022, 1105, 14225, 73840120);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (6, 6, 1, 2022, 1010, 12597, 70095960);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (7, 7, 1, 2022, 1152, 10152, 58948970);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (8, 8, 1, 2022, 1151, 15040, 79050900);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (9, 9, 1, 2022, 1232, 18085, 96791420);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (10, 10, 1, 2022, 302, 4401, 23222790);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (11, 11, 1, 2022, 583, 8595, 50900760);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (12, 12, 1, 2022, 605, 6548, 29677410);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (13, 13, 1, 2022, 1100, 10540, 57268660);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (14, 14, 1, 2022, 92, 1032, 5795020);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (15, 15, 1, 2022, 1524, 17736, 89010110);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (16, 1, 2, 2022, 5469, 82562, 458690100);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (17, 2, 2, 2022, 1285, 14615, 82701060);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (18, 3, 2, 2022, 1238, 16640, 90520420);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (19, 4, 2, 2022, 1626, 22725, 119646610);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (20, 5, 2, 2022, 1104, 14002, 73518540);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (21, 6, 2, 2022, 1004, 12621, 69904080);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (22, 7, 2, 2022, 1129, 11389, 64952780);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (23, 8, 2, 2022, 1141, 14601, 73802970);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (24, 9, 2, 2022, 1232, 17462, 93123990);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (25, 10, 2, 2022, 305, 4436, 23605620);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (26, 11, 2, 2022, 582, 8827, 51300450);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (27, 12, 2, 2022, 603, 6309, 28839120);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (28, 13, 2, 2022, 1101, 9984, 55465820);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (29, 14, 2, 2022, 92, 1039, 20623770);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (30, 15, 2, 2022, 1517, 16775, 84721300);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (31, 1, 3, 2022, 5484, 75811, 430323160);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (32, 2, 3, 2022, 1279, 14057, 80307670);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (33, 3, 3, 2022, 1240, 14872, 82724850);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (34, 4, 3, 2022, 1612, 20379, 110442900);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (35, 5, 3, 2022, 1101, 12103, 66872480);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (36, 6, 3, 2022, 1001, 10198, 60479780);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (37, 7, 3, 2022, 1125, 9612, 57991600);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (38, 8, 3, 2022, 1130, 13355, 68082740);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (39, 9, 3, 2022, 1225, 14998, 82810010);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (40, 10, 3, 2022, 303, 3917, 21678360);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (41, 11, 3, 2022, 578, 8443, 50466920);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (42, 12, 3, 2022, 593, 5461, 26539040);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (43, 13, 3, 2022, 1098, 8635, 51839100);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (44, 14, 3, 2022, 91, 820, 8146270);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (45, 15, 3, 2022, 1517, 14752, 77918770);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (46, 1, 4, 2022, 5474, 80578, 447638020);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (47, 2, 4, 2022, 1265, 14645, 80351260);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (48, 3, 4, 2022, 1241, 15831, 88015940);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (49, 4, 4, 2022, 1605, 22479, 118600780);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (50, 5, 4, 2022, 1099, 14494, 74441320);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (51, 6, 4, 2022, 999, 12155, 66892690);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (52, 7, 4, 2022, 1121, 10304, 60699280);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (53, 8, 4, 2022, 1130, 13950, 70260960);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (54, 9, 4, 2022, 1222, 17370, 91990100);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (55, 10, 4, 2022, 301, 4321, 23123560);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (56, 11, 4, 2022, 577, 8709, 51166680);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (57, 12, 4, 2022, 586, 6592, 29505790);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (58, 13, 4, 2022, 1099, 10478, 56598930);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (59, 14, 4, 2022, 91, 993, 8595310);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (60, 15, 4, 2022, 1517, 15955, 81762170);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (61, 1, 5, 2022, 5501, 83700, 460970270);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (62, 2, 5, 2022, 1256, 16465, 87408160);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (63, 3, 5, 2022, 1234, 18219, 96638990);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (64, 4, 5, 2022, 1616, 24349, 126505150);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (65, 5, 5, 2022, 1104, 15696, 79116240);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (66, 6, 5, 2022, 1004, 12800, 69673160);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (67, 7, 5, 2022, 1117, 9690, 57605340);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (68, 8, 5, 2022, 1126, 16182, 79137640);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (69, 9, 5, 2022, 1227, 17566, 93280260);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (70, 10, 5, 2022, 302, 4550, 24365450);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (71, 11, 5, 2022, 574, 8867, 51374490);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (72, 12, 5, 2022, 588, 6645, 29620510);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (73, 13, 5, 2022, 1090, 11479, 59338100);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (74, 14, 5, 2022, 91, 1149, 9289450);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (75, 15, 5, 2022, 1509, 18803, 91749130);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (76, 1, 6, 2022, 5518, 78832, 441045730);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (77, 2, 6, 2022, 1250, 13216, 75633290);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (78, 3, 6, 2022, 1238, 14978, 83191330);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (79, 4, 6, 2022, 1611, 20418, 110196700);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (80, 5, 6, 2022, 1104, 12525, 67475200);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (81, 6, 6, 2022, 1004, 11173, 63754160);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (82, 7, 6, 2022, 1111, 9937, 58960230);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (83, 8, 6, 2022, 1118, 14259, 71224650);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (84, 9, 6, 2022, 1227, 17952, 94646920);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (85, 10, 6, 2022, 301, 4258, 23422100);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (86, 11, 6, 2022, 571, 8634, 49907350);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (87, 12, 6, 2022, 588, 6311, 28725690);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (88, 13, 6, 2022, 1089, 10461, 56566070);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (89, 14, 6, 2022, 91, 1059, 8882090);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (90, 15, 6, 2022, 1506, 14621, 77882430);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (91, 1, 7, 2022, 5497, 76080, 428469390);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (92, 2, 7, 2022, 1252, 13862, 78129880);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (93, 3, 7, 2022, 1244, 17428, 91685570);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (94, 4, 7, 2022, 1619, 22589, 120348470);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (95, 5, 7, 2022, 1101, 13477, 71171680);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (96, 6, 7, 2022, 1005, 11753, 66708910);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (97, 7, 7, 2022, 1090, 8413, 52125140);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (98, 8, 7, 2022, 1109, 13388, 67200810);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (99, 9, 7, 2022, 1229, 17570, 93275520);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (100, 10, 7, 2022, 300, 3573, 19951470);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (101, 11, 7, 2022, 572, 8855, 52097180);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (102, 12, 7, 2022, 584, 6108, 28527060);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (103, 13, 7, 2022, 1088, 9737, 54567070);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (104, 14, 7, 2022, 89, 1081, 8853350);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (105, 15, 7, 2022, 1492, 16018, 81885140);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (106, 1, 8, 2022, 5474, 80239, 456149450);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (107, 2, 8, 2022, 1254, 15994, 85563190);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (108, 3, 8, 2022, 1244, 18525, 95050630);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (109, 4, 8, 2022, 1605, 23274, 121012190);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (110, 5, 8, 2022, 1099, 13985, 72946420);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (111, 6, 8, 2022, 1006, 12447, 68168370);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (112, 7, 8, 2022, 1051, 8315, 51540230);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (113, 8, 8, 2022, 1101, 15012, 73485530);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (114, 9, 8, 2022, 1229, 17599, 92313260);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (115, 10, 8, 2022, 300, 4224, 22464620);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (116, 11, 8, 2022, 570, 8674, 51218010);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (117, 12, 8, 2022, 585, 6222, 28518390);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (118, 13, 8, 2022, 1089, 11401, 61051960);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (119, 14, 8, 2022, 91, 1220, 9495350);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (120, 15, 8, 2022, 1495, 16845, 84349480);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (121, 1, 9, 2022, 5535, 80329, 456528660);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (122, 2, 9, 2022, 1277, 15312, 85329560);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (123, 3, 9, 2022, 1268, 19235, 103011940);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (124, 4, 9, 2022, 1620, 23889, 126606810);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (125, 5, 9, 2022, 1119, 14442, 75828590);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (126, 6, 9, 2022, 1028, 13515, 73372990);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (127, 7, 9, 2022, 1054, 8642, 56941190);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (128, 8, 9, 2022, 1127, 14492, 72567170);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (129, 9, 9, 2022, 1273, 19139, 100730270);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (130, 10, 9, 2022, 303, 4577, 26274550);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (131, 11, 9, 2022, 577, 9118, 54111560);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (132, 12, 9, 2022, 583, 6911, 31497080);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (133, 13, 9, 2022, 1158, 11894, 64982810);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (134, 14, 9, 2022, 101, 1496, 10948320);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (135, 15, 9, 2022, 1527, 17761, 87702480);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (136, 1, 10, 2022, 5551, 78612, 449664840);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (137, 2, 10, 2022, 1275, 15296, 83707500);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (138, 3, 10, 2022, 1262, 18155, 97295380);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (139, 4, 10, 2022, 1642, 23794, 127015780);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (140, 5, 10, 2022, 1115, 13246, 70889370);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (141, 6, 10, 2022, 1029, 12252, 68259360);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (142, 7, 10, 2022, 1033, 8662, 56277000);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (143, 8, 10, 2022, 1122, 14429, 71989930);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (144, 9, 10, 2022, 1272, 18945, 100084210);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (145, 10, 10, 2022, 301, 4221, 23826730);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (146, 11, 10, 2022, 579, 9295, 55577030);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (147, 12, 10, 2022, 581, 6601, 30641290);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (148, 13, 10, 2022, 1152, 11428, 61446050);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (149, 14, 10, 2022, 101, 1453, 21368500);
INSERT INTO `data_rekening` (`id_rek`, `id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (150, 15, 10, 2022, 1521, 16782, 83774170);


#
# TABLE STRUCTURE FOR: jabatan
#

DROP TABLE IF EXISTS `jabatan`;

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (1, 'Kabag');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (2, 'Ketua ');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (3, 'Ka UPK');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (4, 'Manager');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (5, 'Kasubag');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (6, 'Pelaksana Administrasi');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (7, 'Pelaksana Teknik');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (8, 'Pelaksana Pelayanan Pelanggan');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (9, 'Anggota');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (10, 'Staf Administrasi');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (11, 'Staf Teknik');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (13, 'Staf Pelayanan Pelanggan');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (15, 'Direktur');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (18, 'Staf Administrasi(Pembaca Meter)');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (19, 'Staf Administrasi(Security)');


#
# TABLE STRUCTURE FOR: karyawan
#

DROP TABLE IF EXISTS `karyawan`;

CREATE TABLE `karyawan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bagian` int(11) NOT NULL,
  `id_subag` int(11) NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `alamat` varchar(256) NOT NULL,
  `agama` varchar(50) NOT NULL,
  `status_pegawai` varchar(50) NOT NULL,
  `nik` varchar(8) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `jenkel` varchar(50) NOT NULL,
  `tmp_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `tgl_masuk` date NOT NULL,
  `aktif` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `id_bagian` (`id_bagian`),
  KEY `id_subag` (`id_subag`),
  KEY `id_jabatan` (`id_jabatan`),
  CONSTRAINT `karyawan_ibfk_1` FOREIGN KEY (`id_subag`) REFERENCES `subag` (`id_subag`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `karyawan_ibfk_2` FOREIGN KEY (`id_bagian`) REFERENCES `bagian` (`id_bagian`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `karyawan_ibfk_3` FOREIGN KEY (`id_jabatan`) REFERENCES `jabatan` (`id_jabatan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4;

INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (1, 3, 6, 1, 'Rosida', 'Sukowiryo, Bondowoso', 'Islam', 'Karyawan Tetap', '12190030', '082302209147', 'Perempuan', 'Bondowoso', '1968-07-28', '1991-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (2, 2, 3, 15, 'April Ariestha Bhirawa', 'Perum Tamansari Indah Bondowoso', 'Islam', 'Karyawan Tetap', '', '085236165969', 'Laki-laki', 'Bondowoso', '1970-04-21', '1992-12-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (4, 6, 14, 2, 'Supriyadi', 'Klabang Bondowoso', 'Islam', 'Karyawan Tetap', '01592049', '085311048058', 'Laki-laki', 'Bondowoso', '1968-05-02', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (5, 1, 1, 1, 'Cipto Kusuma', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '05589009', '085203365470', 'Laki-laki', 'Banyuwangi', '1967-08-11', '1989-05-05', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (6, 2, 3, 1, 'Siti Nuraini', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '01592045', '081336463122', 'Perempuan', 'Bojonegoro', '1968-04-23', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (9, 8, 15, 4, 'I Made Suarjaya', 'Jln. A. Yani Bondowoso', 'Hindu', 'Karyawan Tetap', '11292083', '08123456789', 'Laki-laki', 'Bondowoso', '1972-06-20', '1992-06-20', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (10, 4, 10, 1, 'Mohammad Yunus Anis', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '01959599', '08233510842', 'Laki-laki', 'Lumajang', '1972-01-25', '1995-05-19', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (13, 5, 12, 1, 'Sirajuddin', 'Prajekan', 'Islam', 'Karyawan Tetap', '31190018', '082331851007', 'Laki-laki', 'Bondowoso', '1968-11-10', '1990-02-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (14, 7, 31, 3, 'Sudarso', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '05589007', '081336413514', 'Laki-laki', 'Situbondo', '1968-08-28', '1989-05-23', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (15, 7, 17, 3, 'Sucipno', 'Tegalampel', 'Islam', 'Karyawan Tetap', '31190022', '085234951008', 'Laki-laki', 'Bondowoso', '1968-07-13', '1990-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (16, 7, 23, 3, 'Juhaeni', 'Maesan', 'Islam', 'Karyawan Tetap', '11292069', '085236343743', 'Laki-laki', 'Bondowoso', '1968-05-25', '1992-12-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (17, 2, 4, 5, 'Suhendra Paratu', 'Petung Bondowoso', 'Islam', 'Karyawan Tetap', '01592047', '081217071969', 'Laki-laki', 'Tana Toraja', '1969-03-17', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (18, 7, 17, 6, 'Achmad Roedy Witarsa', 'Hos. Cokroaminoto', 'Islam', 'Karyawan Tetap', '04489005', '081336628789', 'Laki-laki', 'Bondowoso', '1969-03-29', '1989-04-08', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (19, 6, 14, 9, 'Teguh Imam Santuso', 'Tenggarang Bondowoso', 'Islam', 'Karyawan Tetap', '01101105', '082335555997', 'Laki-laki', 'Bondowoso', '1968-07-04', '2001-01-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (20, 7, 21, 3, 'Indrayati', 'Situbondo', 'Islam', 'Karyawan Tetap', '02191031', '085257799751', 'Perempuan', 'Manado', '1967-09-09', '1991-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (21, 7, 28, 3, 'Sundari', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '11012119', '085236139585', 'Laki-laki', 'Bondowoso', '1975-04-15', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (22, 7, 26, 3, 'Rudi Hasyim', 'Badean Bondowoso', 'Islam', 'Karyawan Tetap', '01403108', '085334597710', 'Laki-laki', 'Bondowoso', '1974-11-28', '2003-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (23, 7, 24, 3, 'Suwarna', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '01592055', '085338519245', 'Perempuan', 'Bondowoso', '1971-04-16', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (24, 6, 14, 9, 'Adityas Arief Witjaksono', 'Sekarputih Bondowoso', 'Islam', 'Karyawan Tetap', '01393089', '085257780909', 'Laki-laki', 'Pamekasan', '1971-12-23', '1993-03-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (25, 7, 30, 3, 'Sanur', 'Sukosari Bondowoso', 'Islam', 'Karyawan Tetap', '01993092', '085258547502', 'Laki-laki', 'Sumenep', '1972-04-21', '1993-09-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (26, 7, 20, 3, 'Siti Rosida', 'Prajekan Bondowoso', 'Islam', 'Karyawan Tetap', '02191033', '083854071977', 'Laki-laki', 'Prajekan', '1970-01-01', '1991-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (27, 3, 8, 5, 'Lilik Yuli Andayani', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '02191032', '085235425022', 'Perempuan', 'Bondowoso', '1970-07-16', '1991-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (28, 3, 7, 5, 'Yulia', 'Dabasah Bondowoso', 'Islam', 'Karyawan Tetap', '02191035', '085236558772', 'Perempuan', 'Bondowoso', '1970-07-04', '1991-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (29, 2, 3, 5, 'Misiati', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '11292078', '081233719959', 'Perempuan', 'Bondowoso', '1972-06-29', '1992-12-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (30, 2, 5, 5, 'Linda Anggraita', 'Maesan Bondowoso', 'Islam', 'Karyawan Tetap', '20117147', '085230685485', 'Perempuan', 'Bondowoso', '1992-07-04', '2017-01-20', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (31, 3, 9, 5, 'Dicky Erfan Septiono', 'Badean Bondowoso', 'Islam', 'Karyawan Tetap', '01410112', '0816591527', 'Laki-laki', 'Bondowoso', '1978-09-20', '2010-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (32, 4, 11, 5, 'Suwantono', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '01592053', '085258176532', 'Laki-laki', 'Bondowoso', '1971-03-06', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (33, 1, 1, 5, 'Nuning Handayani', 'Bataan Bondowoso', 'Islam', 'Karyawan Tetap', '01592046', '081317174139', 'Laki-laki', 'Bondowoso', '1972-05-25', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (34, 7, 31, 6, 'Andrayani', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '01592044', '085258038337', 'Perempuan', 'Bondowoso', '1971-04-20', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (35, 7, 31, 7, 'Rudy Himawan', 'Curahdami Bondowoso', 'Islam', 'Karyawan Tetap', '11292068', '081249804300', 'Laki-laki', 'Kediri', '1971-04-20', '1992-12-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (36, 7, 22, 7, 'Fitriadi Suryono', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '01592060', '085230266428', 'Laki-laki', 'Jember', '1971-11-21', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (37, 3, 8, 10, 'Yuliatin Jumariyah', 'Garahan Jember', 'Islam', 'Karyawan Tetap', '28893102', '085233763257', 'Perempuan', 'Jember', '1975-07-31', '1993-08-28', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (38, 7, 22, 3, 'Mohammad Rois', 'Curahdami Bondowoso', 'Islam', 'Karyawan Tetap', '11012118', '082330104146', 'Laki-laki', 'Bondowoso', '1978-04-18', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (39, 7, 25, 3, 'Rahmat Febri Eko Tanyono', 'Jember', 'Islam', 'Karyawan Tetap', '01403046', '085101229001', 'Laki-laki', 'Bojonegoro', '1979-02-17', '2003-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (40, 7, 19, 3, 'Saeful Anshori', 'Kademangan', 'Islam', 'Karyawan Tetap', '10414131', '082330340415', 'Laki-laki', 'Bondowoso', '1982-03-28', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (41, 7, 18, 3, 'Supangkat Harianto', 'Tegalampel', 'Islam', 'Karyawan Tetap', '20117144', '085330849697', 'Laki-laki', 'Malang', '1984-05-11', '2017-01-20', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (42, 7, 23, 7, 'Achmad Novi Patria Budiman', 'Tamansari Bondowoso', 'Islam', 'Karyawan Tetap', '10414125', '082316384438', 'Laki-laki', 'Bondowoso', '1975-11-12', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (43, 7, 18, 11, 'Rudi Heriyanto', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '01592058', '081217894120', 'Laki-laki', 'Bondowoso', '1970-05-24', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (44, 7, 26, 10, 'Titin Sri Murtinah', 'Koncer Bondowoso', 'Islam', 'Karyawan Tetap', '01493086', '085236039200', 'Perempuan', 'Bondowoso', '1971-07-20', '1993-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (45, 7, 31, 13, 'Sulistyowati', 'Grujugan Bondowoso', 'Islam', 'Karyawan Tetap', '11012121', '085258559926', 'Perempuan', 'Bondowoso', '1981-11-21', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (46, 7, 31, 8, 'Sohibul Fadillah', 'Maesan Bondowoso', 'Islam', 'Karyawan Tetap', '20117146', '082233598935', 'Perempuan', 'Bondowoso', '1995-06-17', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (47, 7, 18, 7, 'Santuso', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Tetap', '11292080', '081336197752', 'Laki-laki', 'Bondowoso', '1967-08-26', '1992-12-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (48, 7, 30, 6, 'Fathorrasi', 'Badean Bondowoso', 'Islam', 'Karyawan Tetap', '10414134', '085259621069', 'Laki-laki', 'Bondowoso', '1973-01-24', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (49, 7, 27, 3, 'Sugijono', 'Maesan Bondowoso', 'Islam', 'Karyawan Tetap', '31190016', '085310333737', 'Laki-laki', 'Jember', '1968-02-23', '1990-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (50, 7, 31, 13, 'Erfan', 'Kotakulon Bondowoso', 'Islam', 'Karyawan Tetap', '01592062', '085258191743', 'Laki-laki', 'Bondowoso', '1968-08-14', '1992-05-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (51, 7, 31, 18, 'Fahmi Tri Andika', 'Kotakulon Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085259001165', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (52, 7, 31, 18, 'Rendra Septian', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081382933339', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (53, 7, 31, 18, 'Ridwan Nurus Zuhur', 'Gebang Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082237746469', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (54, 7, 31, 18, 'Dion  Dwi Sapta R', 'Kembang Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081249805006', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (55, 7, 31, 11, 'Ilyas', 'Bondowoso', 'Islam', 'Karyawan Tetap', '11012114', '082336157245', 'Laki-laki', 'Bondowoso', '1976-09-21', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (56, 7, 31, 11, 'Mahmudi', 'Bondowoso', 'Islam', 'Karyawan Tetap', '11012115', '085257169200', 'Laki-laki', 'Bondowoso', '1969-07-05', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (57, 7, 31, 11, 'Audri Dwi Putra Nurilahi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '089619600254', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (58, 7, 31, 11, 'Wijaya Kusuma', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085236005991', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (59, 7, 31, 13, 'Ilham Kamil Adi Iskandar', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082228111207', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (60, 7, 31, 11, 'Anton Sujarwo', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085259061773', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (61, 7, 31, 11, 'Moh Hadi Sutrisno', 'Curahdami Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085232903540', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (62, 3, 8, 10, 'Muhammad Deni Saputro', 'Grujugan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083117513423', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (63, 3, 8, 10, 'Somaya Dewantari', 'Dabasah Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085232330042', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (64, 3, 9, 10, 'Achmad Wahyu Dian P', 'Kademangan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085230993424', 'Laki-laki', 'Bondowoso', '2017-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (65, 1, 1, 10, 'Bachtiar C Nuangga', 'Sukosari Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085228134138', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (66, 1, 1, 10, 'Faradiela Sakti Ananda', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085258999009', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (67, 6, 14, 9, 'Inaka Patria Farino', 'Dabasah Bondowoso', 'Islam', 'Karyawan Honorer', '', '083847782219', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (68, 6, 14, 9, 'Bagas Ridha Tria S', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082141601557', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (69, 5, 12, 10, 'Agus Ridwan Firdaus', 'Jember', 'Islam', 'Karyawan Tetap', '31119154', '085336516320', 'Laki-laki', 'Bondowoso', '1988-08-20', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (70, 5, 12, 10, 'Resty Ageng Permatasari', 'Bondowoso', 'Islam', 'Karyawan Tetap', '20117149', '082228101715', 'Perempuan', 'Jember', '1984-09-06', '2017-01-20', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (71, 5, 12, 10, 'Sonya Desiana Mangiri', 'Koncer Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082141841544', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (72, 5, 13, 10, 'Ainun Febriana', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082228830285', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (73, 4, 10, 5, 'Didik Ahmad Rafidi', 'Bondowoso', 'Islam', 'Karyawan Tetap', '10414129', '085234951484', 'Laki-laki', 'Bondowoso', '1981-09-08', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (74, 4, 10, 11, 'Taufiqurrahman', 'Klabang Bondowoso', 'Islam', 'Karyawan Tetap', '31119158', '082335338758', 'Laki-laki', 'Bondowoso', '1996-01-23', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (75, 4, 10, 11, 'Moh Hafi Anshori', 'Tamansari Bondowoso', 'Islam', 'Karyawan Tetap', '31119159', '082338733342', 'Laki-laki', 'Jember', '1990-09-11', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (76, 4, 10, 11, 'Rizal Akbar Rusmana', 'Tegalampel Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082231275038', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (77, 4, 10, 11, 'Haryo Ari Wibowo', 'Tamanan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085291714958', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (78, 2, 5, 10, 'Annur Darmawan', 'Bataan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081230695407', 'Laki-laki', 'Bondowoso', '1999-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (79, 2, 4, 10, 'Vika Ardian Farikasari', 'Tegalampel Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083847168808', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (80, 2, 3, 19, 'M Budi Hartono', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082142113872', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (81, 2, 3, 19, 'Septa Ragiel P', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085961563373', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (82, 2, 3, 19, 'Adi Fitri Fauzi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '087760295756', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (83, 2, 3, 19, 'M Nasir', 'Tlogosari Bondowoso', 'Islam', 'Karyawan Honorer', '', '082301708091', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (84, 2, 3, 10, 'Mohammad Handoko', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '01410111', '089685617475', 'Laki-laki', 'Bondowoso', '1969-04-06', '2010-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (85, 2, 3, 10, 'Fathor Rozyi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085714928475', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (86, 2, 3, 10, 'Mohammad Sugeng Prayogo', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081259943704', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (87, 2, 3, 10, 'Hendi Hendra Laksya Utama', 'Kembang Bondowoso', 'Islam', 'Karyawan Tetap', '10414139', '085231315707', 'Laki-laki', 'Bondowoso', '1978-12-12', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (88, 2, 3, 10, 'Bayu Nur Sito Utomo', 'Kembang Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082332070150', 'Laki-laki', 'Bondowoso', '1991-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (89, 2, 3, 10, 'Dian Irfan Hanugerah', 'Kembang Bondowoso', 'Islam', 'Karyawan Honorer', '', '081916059888', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (90, 2, 3, 10, 'Mohamad Fajar Kurniawan', 'Jember', 'Islam', 'Karyawan Kontrak', '', '08818457609', 'Laki-laki', 'Jember', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (91, 2, 3, 10, 'Moh Iqbal Septiadi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085157236199', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (92, 2, 3, 10, 'M. Boby Kurniawan', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085850617726', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (93, 2, 3, 10, 'Angger Wilujeng', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '087888022255', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (94, 2, 3, 10, 'Daniel Wima Pratama', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085234760170', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (95, 7, 24, 7, 'Arsono Agus Prayudi', 'Bondowoso', 'Islam', 'Karyawan Tetap', '01493085', '082230903020', 'Laki-laki', 'Bondowoso', '1978-02-13', '1993-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (96, 7, 22, 10, 'Tri Puji Rahayu Ningsih', 'Bondowoso', 'Islam', 'Karyawan Tetap', '01403107', '085843071984', 'Perempuan', 'Jember', '1975-11-19', '2003-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (97, 7, 24, 6, 'Anita Kusumayani', 'Bondowoso', 'Islam', 'Karyawan Tetap', '11012120', '082230899665', 'Perempuan', 'Bondowoso', '1974-08-10', '2012-10-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (98, 7, 23, 11, 'Jumanto', 'Wringin', 'Islam', 'Karyawan Tetap', '10414122', '', 'Laki-laki', 'Bondowoso', '1972-02-17', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (99, 7, 22, 11, 'Ajir', 'Wringin', 'Islam', 'Karyawan Tetap', '10414123', '085334589781', 'Laki-laki', 'Bondowoso', '1972-07-28', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (100, 7, 21, 7, 'Wiwik', 'Tapen Bondowoso', 'Islam', 'Karyawan Tetap', '10414124', '085257999823', 'Laki-laki', 'Bondowoso', '1975-07-18', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (101, 7, 30, 11, 'Sudarmo', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '10414128', '085236266632', 'Laki-laki', 'Bondowoso', '1975-01-26', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (102, 7, 22, 11, 'Rafi I', 'Tlogosari Bondowoso', 'Islam', 'Karyawan Tetap', '10414132', '085230210417', 'Laki-laki', 'Bondowoso', '1968-05-19', '2016-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (103, 7, 17, 11, 'Bahrul Ulum', 'Curahdami Bondowoso', 'Islam', 'Karyawan Tetap', '10414137', '085234017564', 'Laki-laki', 'Bondowoso', '1983-07-10', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (104, 7, 23, 11, 'Sulasis', 'Wringin', 'Islam', 'Karyawan Tetap', '10414141', '085259073073', 'Laki-laki', 'Bondowoso', '1973-11-15', '2014-04-10', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (105, 7, 30, 11, 'Lutfi Alfan Rahmatullah', 'Bondowoso', 'Islam', 'Karyawan Tetap', '20117142', '081336336445', 'Laki-laki', 'Bondowoso', '1984-01-21', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (106, 7, 18, 11, 'Sugiono', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '20117143', '085259221782', 'Laki-laki', 'Bondowoso', '1981-07-08', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (107, 7, 28, 7, 'Sayudi', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '20117145', '082323808536', 'Laki-laki', 'Bondowoso', '1984-07-31', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (108, 7, 28, 11, 'Abdul Jamil', 'Bondowoso', 'Islam', 'Karyawan Tetap', '20117148', '085231344616', 'Laki-laki', 'Bondowoso', '1987-12-26', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (109, 7, 19, 6, 'Devita Oktaviani', 'Locare Bondowoso', 'Islam', 'Karyawan Tetap', '20117150', '083840388438', 'Perempuan', 'Bondowoso', '1994-10-06', '2017-01-02', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (110, 7, 17, 11, 'Beni Puji Raharjo', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Tetap', '31119151', '081947615037', 'Laki-laki', 'Bondowoso', '1991-06-26', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (111, 7, 19, 11, 'M Arief Teguh Andiyanto', 'Bondowoso', 'Islam', 'Karyawan Tetap', '31119152', '082141492394', 'Laki-laki', 'Bondowoso', '1976-06-28', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (112, 7, 21, 10, 'Saiful Bari', 'Badean Bondowoso', 'Islam', 'Karyawan Tetap', '311 19 1', '085335111027', 'Laki-laki', 'Situbondo', '1987-03-06', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (113, 8, 35, 10, 'Muh Abd Cholil', 'Bondowoso', 'Islam', 'Karyawan Tetap', '31119155', '082324897200', 'Laki-laki', 'Bondowoso', '1983-04-01', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (114, 7, 19, 7, 'Hidayatullah Firdaus', 'Bondowoso', 'Islam', 'Karyawan Tetap', '31119156', '082233120549', 'Laki-laki', 'Bondowoso', '1976-11-06', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (115, 7, 20, 11, 'Sutikno', 'Gebang Bondowoso', 'Islam', 'Karyawan Tetap', '31119157', '082331354069', 'Laki-laki', 'Bondowoso', '1986-03-08', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (116, 7, 21, 10, 'Andre Rico Aliffiansyah', 'Prajekan Bondowoso', 'Islam', 'Karyawan Tetap', '31119160', '082244976515', 'Laki-laki', 'Treanggalek', '1995-05-02', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (117, 7, 23, 10, 'Ratih Nur Azizatuz Zuhro', 'Pakem Bondowoso', 'Islam', 'Karyawan Tetap', '31119161', '085236537052', 'Perempuan', 'Bondowoso', '1993-01-30', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (118, 7, 17, 11, 'Wawan Budianto', 'Sukosari Bondowoso', 'Islam', 'Karyawan Tetap', '31119162', '082139022511', 'Laki-laki', 'Bondowoso', '1993-02-15', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (119, 7, 27, 18, 'Andriya Ikfa Nurul Ms', 'Bataan Bondowoso', 'Islam', 'Karyawan Tetap', '31119164', '082283884577', 'Laki-laki', 'Malang', '1994-08-01', '2019-01-31', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (120, 7, 25, 18, 'Ananta Prayogi', 'Kotakulon Bondowoso', 'Islam', 'Karyawan Tetap', '28423167', '082245520624', 'Laki-laki', 'Bondowoso', '1993-03-27', '2023-04-28', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (121, 7, 26, 18, 'Moh Iqbal Bachtiar', 'Bondowoso', 'Islam', 'Karyawan Tetap', '', '082233831357', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (122, 7, 30, 10, 'Mohlasi', 'Tegalampel Bondowoso', 'Islam', 'Karyawan Tetap', '', '089682212739', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (123, 7, 25, 10, 'Novi Sundari Subaidah', 'Maesan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082330926669', 'Perempuan', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (124, 7, 25, 11, 'Moh Sofyan Hadi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085234452462', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (125, 7, 17, 10, 'Andika Eka Prayudi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085232472763', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (126, 7, 17, 11, 'Syaifullah', 'Sukosari Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081252190579', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (127, 7, 17, 18, 'Tegar Ubaidhir Rahman', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '081259495726', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (128, 7, 18, 18, 'Hendrik Efendi', 'Maesan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081335464652', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (129, 7, 18, 10, 'Mustika Aditya Pratiwi', 'Sukowiryo Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085732571483', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (130, 7, 19, 18, 'Abdul Wahid', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082335552926', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (131, 7, 19, 11, 'Alfian Maulana Rosyidi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081332323828', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (132, 7, 19, 11, 'Andi Siswanto', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083115872049', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (133, 7, 19, 10, 'Imam Kusairi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082330109338', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (134, 7, 20, 10, 'Ardiansyah Wahyu R H', 'Tapen Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081336603300', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (135, 7, 20, 11, 'Doddy Arifaldi Yuniargo', 'Prajekan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081231904530', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (136, 7, 20, 18, 'Farozi Dwi Julianto', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082245284740', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (137, 7, 20, 11, 'Hafidzul Ahkam', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '081232608664', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (138, 7, 20, 11, 'Dharma Marisca', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '089656525722', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (139, 7, 21, 18, 'Nasrullah', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085231140559', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (140, 7, 21, 11, 'Rohmat Maulana', 'Prajekan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081252722169', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (141, 7, 21, 11, 'Muhammad Akbar Maulana', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Honorer', '', '088237670090', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (142, 7, 22, 18, 'Muhammad Imam Badri', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '082264218348', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (143, 7, 22, 11, 'Lutfi Arip', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081133318314', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (144, 7, 22, 11, 'Jasit', 'Tlogosari Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082112200645', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (145, 7, 23, 18, 'Adi Suharsono', 'Wringin Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081133318312', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (146, 7, 23, 11, 'Firman Hidayah', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082233010077', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (147, 7, 23, 11, 'Junaedi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081230656346', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (148, 7, 24, 18, 'Guntur Hermawan', 'Gebang Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085331301116', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (149, 7, 24, 11, 'Renaldi Ramadan', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085336300788', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (150, 7, 24, 11, 'Ahmad Fatoni', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085334529202', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (151, 7, 24, 11, 'M Awat', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081216416136', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (152, 7, 26, 11, 'Bayu Candra Wicaksono', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082334070443', 'Laki-laki', 'Bondowoso', '1980-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (153, 7, 26, 11, 'Thesar Wahyu Ardiansyah', 'Nangkaan Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082141451739', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (154, 7, 27, 10, 'Anugerah Riski Fardana', 'Koncer Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085210675373', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (155, 7, 27, 11, 'Abdul Basit Junaidi', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082237334786', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (156, 7, 28, 11, 'Andi Rahmat Hakim', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081946132195', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (157, 7, 28, 18, 'Ahmad Muzammil', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085234621803', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (158, 7, 28, 11, 'Teguh Umar F', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085230689119', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (159, 7, 28, 11, 'Reza Satria Airlangga', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085607963612', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (160, 7, 28, 11, 'Prasetyo Dwi Risqianto', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085745789015', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (161, 7, 30, 11, 'Sintoso', 'Prajekan Bondowoso', 'Islam', 'Karyawan Tetap', '01410109', '', 'Laki-laki', 'Bondowoso', '1972-09-06', '2010-04-01', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (162, 7, 30, 11, 'Bayu Prianto', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082230160046', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (163, 7, 30, 11, 'Andika Juni Suharyanto', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082143165806', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (164, 7, 30, 10, 'Dika Pratama', 'Tenggarang Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082339143730', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (165, 7, 30, 18, 'Firman Damansyah', 'Pujer Bondowoso', 'Islam', 'Karyawan Kontrak', '', '081330811600', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (166, 8, 4, 10, 'Putra Raga Adityamala', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083874580762', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (167, 8, 32, 10, 'Reza Yudianto', 'Petung Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082330433653', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (168, 8, 35, 10, 'Yosef Nasoka', 'Petung Bondowoso', 'Islam', 'Karyawan Kontrak', '', '085204937722', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (169, 8, 4, 10, 'Ardiylla Rosza', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083198579633', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (170, 8, 35, 10, 'Dwi Bekti Hariyanto', 'Pancoran Bondowoso', 'Islam', 'Karyawan Kontrak', '', '083872907252', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (171, 8, 34, 10, 'Muhammad Zainul Hasan', 'Bondowoso', 'Islam', 'Karyawan Kontrak', '', '082335519390', 'Laki-laki', 'Bondowoso', '1990-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (172, 8, 34, 10, 'Zainul Hasan', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '085233355118', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (173, 8, 34, 10, 'Ali Shadikin', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '082142101456', 'Laki-laki', 'Bondowoso', '2000-01-01', '0000-00-00', 1);
INSERT INTO `karyawan` (`id`, `id_bagian`, `id_subag`, `id_jabatan`, `nama`, `alamat`, `agama`, `status_pegawai`, `nik`, `no_hp`, `jenkel`, `tmp_lahir`, `tgl_lahir`, `tgl_masuk`, `aktif`) VALUES (174, 8, 4, 10, 'Chinta Adelita Diva', 'Bondowoso', 'Islam', 'Karyawan Honorer', '', '081249800779', 'Perempuan', 'Bondowoso', '2000-01-01', '0000-00-00', 1);


#
# TABLE STRUCTURE FOR: kendaraan
#

DROP TABLE IF EXISTS `kendaraan`;

CREATE TABLE `kendaraan` (
  `id_kendaraan` int(11) NOT NULL AUTO_INCREMENT,
  `id_karyawan` int(11) NOT NULL,
  `id_merk` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `no_plat` varchar(9) NOT NULL,
  `no_rangka` varchar(20) NOT NULL,
  `no_mesin` varchar(20) NOT NULL,
  `jumlah_roda` varchar(1) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `warna` varchar(10) NOT NULL,
  `bahan_bakar` varchar(50) NOT NULL,
  `berlaku_sampai` date NOT NULL,
  PRIMARY KEY (`id_kendaraan`),
  KEY `id_merk` (`id_merk`),
  KEY `id_type` (`id_type`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `kendaraan_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `type` (`id_type`) ON UPDATE CASCADE,
  CONSTRAINT `kendaraan_ibfk_2` FOREIGN KEY (`id_merk`) REFERENCES `merk` (`id_merk`) ON UPDATE CASCADE,
  CONSTRAINT `kendaraan_ibfk_3` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kendaraan` (`id_kendaraan`, `id_karyawan`, `id_merk`, `id_type`, `no_plat`, `no_rangka`, `no_mesin`, `jumlah_roda`, `tahun`, `warna`, `bahan_bakar`, `berlaku_sampai`) VALUES (1, 2, 5, 4, 'P5582AB', '123456789654', 'pl12659877aert', '4', '2012', 'silver', 'Solar', '2022-06-30');
INSERT INTO `kendaraan` (`id_kendaraan`, `id_karyawan`, `id_merk`, `id_type`, `no_plat`, `no_rangka`, `no_mesin`, `jumlah_roda`, `tahun`, `warna`, `bahan_bakar`, `berlaku_sampai`) VALUES (4, 4, 1, 2, 'P3396AB', '1234567988', 'ply12365841tre', '2', '1997', 'Hitam', 'Bensin', '2022-06-25');
INSERT INTO `kendaraan` (`id_kendaraan`, `id_karyawan`, `id_merk`, `id_type`, `no_plat`, `no_rangka`, `no_mesin`, `jumlah_roda`, `tahun`, `warna`, `bahan_bakar`, `berlaku_sampai`) VALUES (6, 6, 1, 5, 'P6953AB', '1234567988', 'ply123658412tre', '2', '2011', 'Hitam', 'Bensin', '2022-06-30');
INSERT INTO `kendaraan` (`id_kendaraan`, `id_karyawan`, `id_merk`, `id_type`, `no_plat`, `no_rangka`, `no_mesin`, `jumlah_roda`, `tahun`, `warna`, `bahan_bakar`, `berlaku_sampai`) VALUES (7, 5, 1, 3, 'P3385AB', '1234567988', 'ply12365841tre', '2', '2018', 'Hitam', 'Bensin', '2022-06-30');


#
# TABLE STRUCTURE FOR: merk
#

DROP TABLE IF EXISTS `merk`;

CREATE TABLE `merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_merk` varchar(50) NOT NULL,
  PRIMARY KEY (`id_merk`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (1, 'Honda');
INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (2, 'Yamaha');
INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (3, 'Suzuki');
INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (4, 'Kawazaki');
INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (5, 'Toyota');
INSERT INTO `merk` (`id_merk`, `nama_merk`) VALUES (7, 'Daihatsu');


#
# TABLE STRUCTURE FOR: nama_upk
#

DROP TABLE IF EXISTS `nama_upk`;

CREATE TABLE `nama_upk` (
  `id_upk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_upk` varchar(100) NOT NULL,
  PRIMARY KEY (`id_upk`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (1, 'Bondowoso');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (2, 'Sukosari 1');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (3, 'Maesan');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (4, 'Tegalampel');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (5, 'Tapen');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (6, 'Prajekan');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (7, 'Tlogosari');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (8, 'Wringin');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (9, 'Curahdami');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (10, 'Tamanan');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (11, 'Tenggarang');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (12, 'TamanKrocok');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (13, 'Wonosari');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (14, 'Klabang');
INSERT INTO `nama_upk` (`id_upk`, `nama_upk`) VALUES (15, 'Sukosari 2');


#
# TABLE STRUCTURE FOR: subag
#

DROP TABLE IF EXISTS `subag`;

CREATE TABLE `subag` (
  `id_subag` int(11) NOT NULL AUTO_INCREMENT,
  `nama_subag` varchar(50) NOT NULL,
  PRIMARY KEY (`id_subag`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (1, 'Langganan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (2, 'Penagihan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (3, 'Umum');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (4, 'Administrasi');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (5, 'Personalia');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (6, 'Keuangan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (7, 'Kas');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (8, 'Pembukuan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (9, 'Rekening');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (10, 'Pemeliharaan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (11, 'Peralatan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (12, 'Perencanaan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (13, 'Pengawasan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (14, 'S P I');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (15, 'A M D K');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (16, 'I T');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (17, 'Sukosari 1');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (18, 'Maesan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (19, 'Tegalampel');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (20, 'Tapen');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (21, 'Prajekan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (22, 'Tlogosari');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (23, 'Wringin');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (24, 'Curahdami');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (25, 'Tamanan');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (26, 'Tenggarang');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (27, 'Tamankrocok');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (28, 'Wonosari');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (29, 'Klabang');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (30, 'Sukosari 2');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (31, 'Bondowoso');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (32, 'Quality Control');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (34, 'Pemasaran');
INSERT INTO `subag` (`id_subag`, `nama_subag`) VALUES (35, 'Produksi');


#
# TABLE STRUCTURE FOR: tbl_bondowoso
#

DROP TABLE IF EXISTS `tbl_bondowoso`;

CREATE TABLE `tbl_bondowoso` (
  `id_upk` int(11) NOT NULL AUTO_INCREMENT,
  `bln` int(2) NOT NULL,
  `thn` int(4) NOT NULL,
  `jml_rek` int(11) NOT NULL,
  `air_pakai` int(11) NOT NULL,
  `rupiah` int(11) NOT NULL,
  PRIMARY KEY (`id_upk`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_bondowoso` (`id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (1, 1, 2022, 5491, 84451, 466540360);
INSERT INTO `tbl_bondowoso` (`id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (2, 2, 2022, 5469, 82562, 458690100);
INSERT INTO `tbl_bondowoso` (`id_upk`, `bln`, `thn`, `jml_rek`, `air_pakai`, `rupiah`) VALUES (3, 3, 2022, 5484, 75811, 430323160);


#
# TABLE STRUCTURE FOR: type
#

DROP TABLE IF EXISTS `type`;

CREATE TABLE `type` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `nama_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `type` (`id_type`, `nama_type`) VALUES (1, 'Revo X');
INSERT INTO `type` (`id_type`, `nama_type`) VALUES (2, 'Revo Fit');
INSERT INTO `type` (`id_type`, `nama_type`) VALUES (3, 'Win 100');
INSERT INTO `type` (`id_type`, `nama_type`) VALUES (4, ' Innova');
INSERT INTO `type` (`id_type`, `nama_type`) VALUES (5, 'Supra X');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengguna` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `level` varchar(50) NOT NULL DEFAULT 'Pengguna',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (1, 'bilal', 'Bilal Zaidan', 'bilal@gmail.com', '$2y$10$ADv3d1BXOHDyYXGYOHouhu8B.rE4GiayKwPcrFMrMFwJXCzjtBckq', 'Admin');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (2, 'dicky', 'Dicky Erfan Septiono', 'dicky@gmail.com', '$2y$10$8zVag1Z4PHi78euzVSUxY.BzFDqgQm4MD7pkO6ucUBp9/Pc3ye/xG', 'Admin');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (7, 'lembayung', 'Lembayung Biru', 'lembayungbiru@gmail.com', '$2y$10$LLMxK7dAoiwP6k4MHPzis.oATWvQDMCCOkrwSE4muuUmMd4Y3OUxS', 'Admin');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (13, 'Aryan', 'Arya Dwipanggah', 'aryan@gmail.com', '$2y$10$um8k82NQM7XIcySaEnAEQO0fNI0EznhGl91as1JKTXqZzzeXQUpLy', 'Pengguna');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (17, 'pdambws', 'Karyawan PDAM', 'pdambondowoso@gmail.com', '$2y$10$AKE8ylojOK10EU30ssmLQ.psVptbuLsm63a1jp/lEjwQnbd.1FEzS', 'Pengguna');


